﻿# About

Base class project setup for C#9, .NET Core 5

![image](assets/Versions.png)

![img](assets/core_csharp_shield.png)