﻿namespace $safeprojectname$.Classes
{
    public class Class1
    {
    }
}
