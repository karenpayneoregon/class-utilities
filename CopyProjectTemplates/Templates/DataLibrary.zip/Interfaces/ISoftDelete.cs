﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Interfaces
{
    public interface ISoftDelete
    {
        bool IsDeleted { get; set; }
    }
}
