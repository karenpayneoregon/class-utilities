﻿namespace $safeprojectname$.Classes
{
    public class Environment
    {
        public bool Production { get; set; }
        public string Name { get; set; }
    }
}