﻿# About

A stripped down web project which VS2019 does not have a template for although VS2017 does. Seems like Microsoft is directing developers to be ASP.NET Core or nothing.

Karen created a blank project template to do what VS2017 did.